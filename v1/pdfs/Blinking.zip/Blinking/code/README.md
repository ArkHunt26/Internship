
# Blinking LED

The following code is for blinking in-built LED User LD2 PB7 with 3 second ON and 1 second OFF on STM32-L4R5ZI-P. Refer manual for more information.

## Deployment

To deploy this project, copy the code from blinking.txt and paste in main();



## Acknowledgements

THIS IS FOR STM32-L4R5ZI-P board.


## Documentation
NOTE: THE FOLLOWING LINKS/REFERENCE MAY OR MAY NOT BE OF STM32-L4R5ZI-P.

Youtube video reference:

- https://www.youtube.com/watch?v=mOGqNwTjEGM

- https://www.youtube.com/watch?v=oAwZ0cjlmN8

Websites:

- https://wiki.st.com/stm32mcu/wiki/STM32StepByStep:Step2_Blink_LED

- https://deepbluembedded.com/stm32-gpio-write-pin-digital-output-lab/
